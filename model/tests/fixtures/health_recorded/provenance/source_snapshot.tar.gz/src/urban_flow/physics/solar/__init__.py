"""Solar models."""
