"""Wind model implementations."""
